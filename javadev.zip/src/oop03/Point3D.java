package oop03;

public class Point3D extends Point2D{
	int z;
	
	public void test() {
		System.out.println(x);
	}
}
