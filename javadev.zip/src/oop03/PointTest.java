package oop03;

public class PointTest {
	public static void main(String[] args) {
		Point2D pt = new Point2D();
		pt.x = 10;
	}
}
