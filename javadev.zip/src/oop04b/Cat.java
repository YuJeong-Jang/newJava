package oop04b;

public class Cat extends Animal{
	public void jump() {
		System.out.println("고양이가 점프를 합니다.");
	}
}
