package oop04b;

public class Tiger extends Animal{
	public void attack() {
		System.out.println("사자가 공격을 합니다.");
	}
}
