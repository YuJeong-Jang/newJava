package oop04;

public class Point2D {
	int x;
	int y;
	
}
