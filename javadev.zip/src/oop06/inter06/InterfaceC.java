package oop06.inter06;

//interface끼리는 다중상속 가능
public interface InterfaceC extends InterfaceA, InterfaceB{
	public void methodC();
}
