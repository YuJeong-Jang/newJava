package oop06.inter07;

public class MyInterfaceImpl implements MyInterface{

	@Override
	public void myMethod1() {
		System.out.println("myMethod1() 수행");
	}

}
