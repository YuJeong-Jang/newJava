package oop06.inter07;

public class DefaultMethodTest {
	public static void main(String[] args) {
		MyInterface mi = new MyInterfaceImpl();
		mi.myMethod1();
		mi.myMethod2();
	}
}
