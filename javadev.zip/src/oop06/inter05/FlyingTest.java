package oop06.inter05;

public class FlyingTest {
	public static void main(String[] args) {
		FlyingCar car = new FlyingCar();
		car.drive();
		car.fly();
	}
}
