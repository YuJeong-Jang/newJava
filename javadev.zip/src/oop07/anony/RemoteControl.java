package oop07.anony;

public interface RemoteControl {
	public void turnOn();
	public void turnOff();
}
