package oop05.abctract01;

public class Triangle extends Shape{
	int w = 10, h = 5;
	
	public void area() {
		res = w * h / 2;
	}
}
