package oop05.abctract01;

public class Circle extends Shape{
	int r = 10;
	
	public void area() {
		res = r * r * 3.14;
	}
}
