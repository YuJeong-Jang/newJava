package oop11.api;

public class ObjecTest02 {
	public static void main(String[] args) {
		int a = 10;
		int b = 10;

		if (a == b) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}

		String str1 = "안녕하세요";
		String str2 = "안녕하세요";

		if (str1 == str2) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
	}
}
