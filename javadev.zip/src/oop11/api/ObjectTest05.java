package oop11.api;

public class ObjectTest05 {
	public static void main(String[] args) {
		Integer i = 10;	//오토박싱(auto boxing)
		System.out.println(i);
		
		int n = i;
	}
}
