package basic;

public class OpTest02 {
	public static void main(String[] args) {
		int a = 7;
		int b = 4;
		
		System.out.println(a>b);
		System.out.println(a<b);
		System.out.println(a>=b);
		System.out.println(a<=b);
		System.out.println(a==b);
		System.out.println(a!=b);
	}
}
