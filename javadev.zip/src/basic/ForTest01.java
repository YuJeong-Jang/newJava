package basic;
/*
 * for(1초기식; 2조건식; 4증감식;) {
 * 3조건식이 참일때 수행하는 문장
 * }
 */
public class ForTest01 {
	public static void main(String[] args) {
		for(int i=1; i<=3; i++) {
			System.out.println("오라클 자바");
		}
		System.out.println("종료");
	}
}
