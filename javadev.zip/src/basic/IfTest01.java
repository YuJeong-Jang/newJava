package basic;

public class IfTest01 {
	public static void main(String[] args) {
		int n = 7;
		if (n == 1) {
			System.out.println("남자");
		} else if (n == 2) {
			System.out.println("여자");
		} else {
			System.out.println("에러");
		}
		System.out.println("종료");
	}
}