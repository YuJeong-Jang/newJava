package basic;

public class OpTest06 {
	public static void main(String[] args) {
		int a = 5;
		a += 5;	//a = a + 5;
		System.out.println(a);
		
		a -= 5;	//a = a - 5;
		System.out.println(a);
		
		a *= 5;	//a = a * 5;
		System.out.println(a);
		
		a /= 5;	//a = a / 5;
		System.out.println(a);
		
		a %= 5;	//a = a % 5;
		System.out.println(a);
		
	}
}
