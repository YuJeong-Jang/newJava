package oop02.static02;

public class NumberPrinter {
	public static void showInt(int n) {
		System.out.println(n);
	}
	
	public static void showDouble(double n) {
		System.out.println(n);
	}
}
