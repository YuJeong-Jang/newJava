package oop01;

public class PointTest {
	public static void main(String[] args) {
//		Point2D pt1 = new Point2D();
//		pt1.print();
		
//		Point2D pt2 = new Point2D(10, 20);
//		pt2.print();
		
		Point3D pt3 = new Point3D();
		pt3.print();
		
//		Point3D pt4 = new Point3D(100, 200, 300);
//		pt4.print();
		
		
//		Point3D pt = new Point3D();
//		pt.x = 10;
//		pt.y = 20;

//		pt.setX(10);
//		pt.setY(20);
//		pt.setZ(30);
//		pt.print();
	}
}
